import os
from langchain_openai import ChatOpenAI
from browser_use import Agent, BrowserConfig, Browser
import asyncio
from dotenv import load_dotenv
load_dotenv()
GOOGLE_ACCOUNT_EMAIL = os.getenv('GOOGLE_ACCOUNT_EMAIL')
GOOGLE_ACCOUNT_PASSWORD = os.getenv('GOOGLE_ACCOUNT_PASSWORD')

async def main():
    config = BrowserConfig(
        headless=True,
        disable_security=True,
        # new_context_config=BrowserContextConfig(highlight_elements=False),
        browser_binary_path='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        # chrome_instance_path='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        # cdp_url="http://localhost:9222",
        extra_browser_args=["--remote-debugging-port=9222"]
    )

    browser = Browser(config=config)
    agent2 = Agent(
        task="""
        #task
        You need to follow these steps - 
        1. go to https://2captcha.com/demo/normal
        2. read the captcha
        3. enter it into the text box
        """,
        llm=ChatOpenAI(model="gpt-4o"),
        use_vision=True,
        browser=browser,
        save_conversation_path="logs/vision_true_conversation"
    )

    asyncio.gather(agent2.run())

asyncio.run(main())